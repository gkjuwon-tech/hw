Conet Tactile Scanner v1 — manufacturing data
=============================================

Stackup:    4 layers, FR-4, 1.6 mm finished thickness, ENIG (lead-free).
Outline:    60 x 40 mm rounded rectangle, 2 mm corner radius.
Min trace:  0.20 mm. Min via: 0.4/0.2 mm. Min hole: 0.3 mm.

Layer mapping:
  conet-scanner-v1-F_Cu.gbr          Top copper (L1, signal)
  conet-scanner-v1-In1_Cu.gbr        Inner 1   (L2, GND pour)
  conet-scanner-v1-In2_Cu.gbr        Inner 2   (L3, +3V3 pour)
  conet-scanner-v1-B_Cu.gbr          Bottom copper (L4, signal)
  conet-scanner-v1-F_Mask.gbr        Top soldermask
  conet-scanner-v1-B_Mask.gbr        Bottom soldermask
  conet-scanner-v1-F_Paste.gbr       Top solder paste (for SMT stencil)
  conet-scanner-v1-F_Silkscreen.gbr  Top silkscreen
  conet-scanner-v1-B_Silkscreen.gbr  Bottom silkscreen
  conet-scanner-v1-Edge_Cuts.gbr     Mechanical outline
  conet-scanner-v1-PTH.drl           Plated through-hole drills (Excellon)
  conet-scanner-v1-NPTH.drl          Non-plated drills (Excellon)

Pair with `bom.csv` and `cpl.csv` for JLCPCB SMT full-turnkey.
